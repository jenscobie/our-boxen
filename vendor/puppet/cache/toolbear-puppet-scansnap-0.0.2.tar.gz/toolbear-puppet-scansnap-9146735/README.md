# Fujitsu ScanSnap Manager Puppet Module for Boxen

[![Build Status](https://travis-ci.org/toolbear/puppet-scansnap.png?branch=master)](https://travis-ci.org/toolbear/puppet-scansnap)

## Usage

```puppet
include scansnap
```

## Required Puppet Modules

* boxen
